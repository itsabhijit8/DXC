package comm;

import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class msn {
	public WebDriver driver;
	public String Browser="chrome";
	@Test
	public void testcase1(){
		SoftAssert st=  new SoftAssert();
		if(Browser.equalsIgnoreCase("chrome")){
			System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
			driver=new ChromeDriver(); //OpenBrowser
		}else if(Browser.equalsIgnoreCase("mozilla")){
			System.setProperty("webdriver.firefox.marionette", "geckodriver.exe");
			 driver=new FirefoxDriver();
		}else if(Browser.equalsIgnoreCase("ie")){
			System.setProperty("webdriver.ie.driver", "IEDriverServer.exe");
			 driver=new InternetExplorerDriver();
		}
		driver.get("https://www.msn.com/en-in/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		
		driver.findElement(By.xpath("//h3[contains(text(),'OneNote')]")).click();
		
		Set<String>allids=driver.getWindowHandles();
		Iterator<String>it = allids.iterator();
		String mid = it.next();
		String t1 = it.next();
		driver.switchTo().window(t1);
		driver.findElement(By.xpath("//input[@id='i0116']")).sendKeys("934394838");
		driver.close();
		driver.switchTo().window(mid);
		driver.findElement(By.xpath("//h3[contains(text(),'Skype')]")).click();
	}
		
		
		
}
