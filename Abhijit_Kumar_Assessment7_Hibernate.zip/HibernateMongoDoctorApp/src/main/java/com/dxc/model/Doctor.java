package com.dxc.model;

import javax.persistence.Column;
import javax.persistence.Id;

public class Doctor {
	
	
	@Id
	private int docId;
	
	@Column(name="Dname")
	private String docName;
	private Hospital Hdetails;
	
	private int fees;	
	
	public Doctor() {
		// TODO Auto-generated constructor stub
	}

	public Doctor(int docId, String docName, Hospital hdetails, int fees) {
		super();
		this.docId = docId;
		this.docName = docName;
		Hdetails = hdetails;
		this.fees = fees;
	}

	public int getDocId() {
		return docId;
	}

	public void setDocId(int docId) {
		this.docId = docId;
	}

	public String getDocName() {
		return docName;
	}

	public void setDocName(String docName) {
		this.docName = docName;
	}

	public Hospital getHdetails() {
		return Hdetails;
	}

	public void setHdetails(Hospital hdetails) {
		Hdetails = hdetails;
	}

	public int getFees() {
		return fees;
	}

	public void setFees(int fees) {
		this.fees = fees;
	}


	
	
}
