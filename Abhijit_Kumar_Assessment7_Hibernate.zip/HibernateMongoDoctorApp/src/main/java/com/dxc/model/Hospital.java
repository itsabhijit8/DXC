package com.dxc.model;

public class Hospital {
	private String Hname;
	private String Hcity;
	
	public Hospital() {
		// TODO Auto-generated constructor stub
	}

	public String getHname() {
		return Hname;
	}

	public void setHname(String hname) {
		Hname = hname;
	}

	public String getHcity() {
		return Hcity;
	}

	public void setHcity(String hcity) {
		Hcity = hcity;
	}

	public Hospital(String hname, String hcity) {
		super();
		Hname = hname;
		Hcity = hcity;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((Hcity == null) ? 0 : Hcity.hashCode());
		result = prime * result + ((Hname == null) ? 0 : Hname.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Hospital other = (Hospital) obj;
		if (Hcity == null) {
			if (other.Hcity != null)
				return false;
		} else if (!Hcity.equals(other.Hcity))
			return false;
		if (Hname == null) {
			if (other.Hname != null)
				return false;
		} else if (!Hname.equals(other.Hname))
			return false;
		return true;
	}

	
	
	
	

}
