package com.dxc.client.HibernateMongoDemo1;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.ogm.cfg.OgmConfiguration;


import com.dxc.model.Doctor;
import com.dxc.model.Hospital;

public class App 
{
    public static void main( String[] args )
    {
        OgmConfiguration cfg = new OgmConfiguration();
        cfg.configure();
        
        SessionFactory factory = cfg.buildSessionFactory();
        Session session = factory.openSession();
        
        Transaction transaction = session.beginTransaction();
        Hospital obj = new Hospital("Vedanta","Chennai");
        
        Doctor doctor = new Doctor(56, "Abhijit",obj,890);
        
        session.save(doctor);
        transaction.commit();
        
        System.out.println("Data stored in mogodb using annotation");
    }
}
