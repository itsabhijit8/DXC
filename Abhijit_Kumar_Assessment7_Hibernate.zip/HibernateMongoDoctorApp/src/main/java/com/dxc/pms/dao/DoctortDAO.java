package com.dxc.pms.dao;

import java.util.List;

import com.dxc.model.Doctor;


public interface DoctortDAO {
		public Doctor getDoctor(int docId);
		public List<Doctor> getAllDoctor();
		public void addDoctor(Doctor doctor);
		public void deleteDoctor(int docId);
		public void updateDoctor(Doctor doctor);
		public boolean isDoctorExists(int docId);
		public void getAllDoctorNames();
		
}
