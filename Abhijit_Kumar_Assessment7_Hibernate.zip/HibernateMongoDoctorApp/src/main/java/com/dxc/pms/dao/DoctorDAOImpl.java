package com.dxc.pms.dao;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.dxc.model.Doctor;

import com.dxc.pms.util.HibernateUtil;

public class DoctorDAOImpl implements DoctortDAO {
	
	
	SessionFactory sf = HibernateUtil.getSessionFactory();
	
	
	public DoctorDAOImpl() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public Doctor getDoctor(int docId) {
		// TODO Auto-generated method stub
		
		Session session = sf.openSession();
		Doctor doctor = (Doctor)session.get(Doctor.class,docId);
		return doctor;

	}

	@Override
	public List<Doctor> getAllDoctor() {
		// TODO Auto-generated method stub
		Session session = sf.openSession(); 
		  Query query = session.createQuery("from Doctor");
		 
		  return query.list();
		
		
	}

	@Override
	public void addDoctor(Doctor doctor) {
		// TODO Auto-generated method stub
		Session session = sf.openSession();
		Transaction transaction = session.beginTransaction();
		session.save(doctor);
		transaction.commit();
		session.close();
		System.out.println(doctor.getDocName()+"saved succesfully");

	}

	@Override
	public void deleteDoctor(int docId) {
		// TODO Auto-generated method stub
		Session session = sf.openSession();
		Transaction transaction = session.beginTransaction();
		Doctor  doctor = new Doctor();
		doctor.setDocId(docId);
		session.delete(doctor);
		transaction.commit();
		session.close();

	}

	@Override
	public void updateDoctor(Doctor doctor) {
		// TODO Auto-generated method stub
		Session session = sf.openSession();
		Transaction transaction = session.beginTransaction();
		session.saveOrUpdate(doctor);
		transaction.commit();
		session.close();

	}

	@Override
	public boolean isDoctorExists(int docId) {
		// TODO Auto-generated method stub
		Session session = sf.openSession();
		Doctor doctor = (Doctor)session.get(Doctor.class,docId);
		if(doctor == null)
			return false;
		else 
			return true;
		
	}

	@Override
	public void getAllDoctorNames() {
		// TODO Auto-generated method stub
		Session session = sf.openSession();
		Query query = session.createQuery("select docName from Doctor");
		List<String> pr = query.list();
		Iterator<String> iterator1 = pr.iterator();
		
		
		while(iterator1.hasNext()) {
			String p = iterator1.next();
			System.out.println(p);

	}
	}

	
}
