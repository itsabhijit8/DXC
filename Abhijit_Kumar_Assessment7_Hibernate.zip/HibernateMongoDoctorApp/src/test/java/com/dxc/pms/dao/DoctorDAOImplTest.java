package com.dxc.pms.dao;

import java.util.List;

import com.dxc.model.Doctor;
import com.dxc.model.Hospital;

import junit.framework.TestCase;

public class DoctorDAOImplTest extends TestCase {
	
	DoctortDAO dao;

	protected void setUp() throws Exception {
		super.setUp();
	}
	public void testaddDoctor() {
		
		
		Hospital obj = new Hospital("Vedanta", "Bangalore");
		Doctor doctor = new Doctor(1,"Abhi",obj, 890);
		List<Doctor> list=dao.getAllDoctor();
		dao.addDoctor(doctor);
		List<Doctor> list2=dao.getAllDoctor();
		assertNotSame(list.size(), list2.size());
	}
	protected void tearDown() throws Exception {
		super.tearDown();
	}

	public void testDoctorDAOImpl() {
		fail("Not yet implemented");
	}

	public void testGetDoctor() {
		fail("Not yet implemented");
	}

	public void testGetAllDoctor() {
		fail("Not yet implemented");
	}

	public void testAddDoctor() {
		fail("Not yet implemented");
	}

	public void testDeleteDoctor() {
		fail("Not yet implemented");
	}

	public void testUpdateDoctor() {
		fail("Not yet implemented");
	}

	public void testIsDoctorExists() {
		fail("Not yet implemented");
	}

	public void testGetAllDoctorNames() {
		fail("Not yet implemented");
	}

}
