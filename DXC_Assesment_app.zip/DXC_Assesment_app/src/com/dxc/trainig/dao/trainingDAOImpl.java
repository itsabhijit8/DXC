package com.dxc.trainig.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import com.dxc.training.training;
import com.dxc.training.dbcon.DBConnection;

public class trainingDAOImpl implements trainingDAO {
	
	Connection connection = DBConnection.getConnection();
	private static final String FETCH_TABLE_ALL= "select * from training";
	private static final String TYPE_SCROLL_INSENSITIVE;
	private static final String CONCUR_UPDATABLE;
	

	public trainingDAOImpl() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public List<training> getAllData() throws SQLException {
		
		Statement stat= connection.createStatement();
		ResultSet res = stat.executeQuery(FETCH_TABLE_ALL);
		
		
		
		return null;
	}
	
	public void getonebyone() {
		try {
			Statement stat = 
					connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
							ResultSet.CONCUR_UPDATABLE);
			ResultSet res = stat.executeQuery(FETCH_TABLE_ALL);
			ResultSetMetaData rsmd = res.getMetaData();
			while(res.next()) { 
				for (int i = 1; i <= rsmd.getColumnCount(); i++) {
				System.out.print(res.getString(i) + " ");
				}
				System.out.println("\nEnter the percentage you want to update:-");
				percentage= scanner.nextInt();
				
				res.updateInt(3, percentage);
				res.updateRow();
				
	}

}
