package com.dxc.trainig.dao;

import java.sql.SQLException;
import java.util.List;
import com.dxc.training.training;

public interface trainingDAO {
	public List<training>getAllData() throws SQLException;
	
}
