package com.dxc.trainig.dao;

import java.sql.SQLException;

import com.dxc.training.users;

public interface usersDAO {
		public boolean validateUsers(String username,String password) throws SQLException;

}
