package com.dxc.trainig.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.dxc.training.users;
import com.dxc.training.dbcon.DBConnection;

public class usersDAOImpl implements usersDAO {

	Connection connection = DBConnection.getConnection();
	public boolean status = false;

	public usersDAOImpl() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public boolean validateUsers(String username, String password) throws SQLException {

		Statement st = connection.createStatement();
		String queryCheck = "SELECT * from users WHERE Username = Abhijit AND Passowrd = Kumar";
		ResultSet rs = st.executeQuery(queryCheck);
		

		if (rs.next()) {
			status = true;
		}
		return status;
	}

}
