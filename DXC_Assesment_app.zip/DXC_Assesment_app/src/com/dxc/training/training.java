package com.dxc.training;

public class training {
	private int Sap_Id;
	private String Employee_name;
	private String Stream;
	private int Percentage;
	public training() {
		// TODO Auto-generated constructor stub
	}
	public training(int sap_Id, String employee_name, String stream, int percentage) {
		super();
		Sap_Id = sap_Id;
		Employee_name = employee_name;
		Stream = stream;
		Percentage = percentage;
	}
	public int getSap_Id() {
		return Sap_Id;
	}
	public void setSap_Id(int sap_Id) {
		Sap_Id = sap_Id;
	}
	public String getEmployee_name() {
		return Employee_name;
	}
	public void setEmployee_name(String employee_name) {
		Employee_name = employee_name;
	}
	public String getStream() {
		return Stream;
	}
	public void setStream(String stream) {
		Stream = stream;
	}
	public int getPercentage() {
		return Percentage;
	}
	public void setPercentage(int percentage) {
		Percentage = percentage;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((Employee_name == null) ? 0 : Employee_name.hashCode());
		result = prime * result + Percentage;
		result = prime * result + Sap_Id;
		result = prime * result + ((Stream == null) ? 0 : Stream.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		training other = (training) obj;
		if (Employee_name == null) {
			if (other.Employee_name != null)
				return false;
		} else if (!Employee_name.equals(other.Employee_name))
			return false;
		if (Percentage != other.Percentage)
			return false;
		if (Sap_Id != other.Sap_Id)
			return false;
		if (Stream == null) {
			if (other.Stream != null)
				return false;
		} else if (!Stream.equals(other.Stream))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "training [Sap_Id=" + Sap_Id + ", Employee_name=" + Employee_name + ", Stream=" + Stream
				+ ", Percentage=" + Percentage + "]";
	}
	
}
