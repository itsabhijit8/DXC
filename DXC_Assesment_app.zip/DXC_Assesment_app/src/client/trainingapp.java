package client;

import java.sql.SQLException;

import com.dxc.trainig.dao.trainingDAOImpl;
import com.dxc.trainig.dao.usersDAOImpl;

public class trainingapp {

	public trainingapp() {
		
	}
	
	public void display() throws SQLException {
		
		trainingDAOImpl data = new trainingDAOImpl();
		data.getAllData();
	}

}
