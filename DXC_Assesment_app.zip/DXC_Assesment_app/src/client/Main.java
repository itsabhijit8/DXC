package client;

import java.sql.SQLException;

public class Main {

	public Main() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) throws SQLException {
		userapp app = new userapp();
		app.launch();
	}

}
