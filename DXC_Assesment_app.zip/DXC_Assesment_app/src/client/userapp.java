package client;

import java.sql.SQLException;
import java.util.Scanner;

import com.dxc.trainig.dao.trainingDAOImpl;
import com.dxc.trainig.dao.usersDAOImpl;
import com.dxc.training.users;

public class userapp {

	public userapp() {
		usersDAOImpl user = new usersDAOImpl();

	}

	public void launch() throws SQLException {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Please enter username :");
		String uname = scanner.next();
		System.out.println("Please enter password :");
		String pass = scanner.next();

		usersDAOImpl user = new usersDAOImpl();

		if (user.validateUsers(uname, pass)) {
			int choice;
			choice = scanner.nextInt();
			switch(choice) {
			case 1:
				trainingDAOImpl data = new trainingDAOImpl();
				data.getAllData();
				break;
			case 2:
			case 3:
			}
			
		} else {

			System.out.println("Invalid user");
		}
	}

}
